# CloudGuardRailChallenge

## Deployment Instructions

1. Ensure you have the AWS CLI installed and configured with appropriate permissions.
2. Create a bucket in S3 to store your Lambda function code.
3. Zip the `lambda_function` directory and upload it to the S3 bucket.
4. Update the `template.yaml` with the correct S3 bucket name and key for the Lambda function.
5. Deploy the CloudFormation stack using the following command:

   ```bash
   aws cloudformation create-stack --stack-name CloudGuardRailStack --template-body file://template.yaml --parameters ParameterKey=PermissionBoundaryArn,ParameterValue=YOUR_PERMISSION_BOUNDARY_ARN